/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionSalva_tutto;
    QAction *actionNuovo;
    QAction *actionChiudi;
    QAction *actionEsporta_CSV;
    QAction *actionScarico;
    QAction *actionExe;
    QWidget *centralwidget;
    QTabWidget *TabWidget;
    QWidget *Tab1;
    QWidget *layoutWidget;
    QGridLayout *gridLay1;
    QWidget *cella11;
    QWidget *cella3;
    QWidget *cella6;
    QWidget *cella1;
    QWidget *cella2;
    QWidget *cella10;
    QWidget *cella4;
    QWidget *cella8;
    QWidget *cella5;
    QWidget *cella7;
    QWidget *cella9;
    QWidget *cella0;
    QWidget *Tab2;
    QWidget *layoutWidget_2;
    QGridLayout *gridLay2;
    QWidget *cella11_2;
    QWidget *cella3_2;
    QWidget *cella6_2;
    QWidget *cella1_2;
    QWidget *cella2_2;
    QWidget *cella10_2;
    QWidget *cella0_2;
    QWidget *cella4_2;
    QWidget *cella8_2;
    QWidget *cella5_2;
    QWidget *cella7_2;
    QWidget *cella9_2;
    QWidget *Tab3;
    QWidget *layoutWidget_3;
    QGridLayout *gridLay3;
    QWidget *cella11_3;
    QWidget *cella3_3;
    QWidget *cella6_3;
    QWidget *cella1_3;
    QWidget *cella2_3;
    QWidget *cella10_3;
    QWidget *cella0_3;
    QWidget *cella4_3;
    QWidget *cella8_3;
    QWidget *cella5_3;
    QWidget *cella7_3;
    QWidget *cella9_3;
    QWidget *Tab4;
    QWidget *layoutWidget_4;
    QGridLayout *gridLay4;
    QWidget *cella11_4;
    QWidget *cella3_4;
    QWidget *cella6_4;
    QWidget *cella1_4;
    QWidget *cella2_4;
    QWidget *cella10_4;
    QWidget *cella0_4;
    QWidget *cella4_4;
    QWidget *cella8_4;
    QWidget *cella5_4;
    QWidget *cella7_4;
    QWidget *cella9_4;
    QWidget *Tab5;
    QWidget *layoutWidget_5;
    QGridLayout *gridLay5;
    QWidget *cella11_5;
    QWidget *cella3_5;
    QWidget *cella6_5;
    QWidget *cella1_5;
    QWidget *cella2_5;
    QWidget *cella10_5;
    QWidget *cella0_5;
    QWidget *cella4_5;
    QWidget *cella8_5;
    QWidget *cella5_5;
    QWidget *cella7_5;
    QWidget *cella9_5;
    QFrame *frame;
    QWidget *layoutWidget1;
    QGridLayout *gridLayFra;
    QComboBox *comboBox_6;
    QLabel *label_6;
    QComboBox *comboBox_2;
    QLabel *label_10;
    QLabel *label_8;
    QLabel *label_3;
    QLabel *label_2;
    QLabel *label_4;
    QComboBox *comboBox_8;
    QComboBox *comboBox_9;
    QComboBox *comboBox_5;
    QLabel *label_5;
    QComboBox *comboBox_3;
    QComboBox *comboBox;
    QLabel *label_12;
    QLabel *label_7;
    QLabel *label_13;
    QLabel *label_9;
    QComboBox *comboBox_4;
    QLabel *label;
    QComboBox *comboBox_7;
    QLabel *label_11;
    QScrollArea *scrollArea;
    QWidget *scrollContents;
    QPushButton *pushButton;
    QMenuBar *menuBar;
    QMenu *menumenu;
    QMenu *menuOUT;
    QMenu *menuCUT;
    QMenu *menuUsb;
    QStatusBar *statusbar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->setEnabled(true);
        MainWindow->resize(1218, 648);
        actionSalva_tutto = new QAction(MainWindow);
        actionSalva_tutto->setObjectName(QString::fromUtf8("actionSalva_tutto"));
        actionNuovo = new QAction(MainWindow);
        actionNuovo->setObjectName(QString::fromUtf8("actionNuovo"));
        actionChiudi = new QAction(MainWindow);
        actionChiudi->setObjectName(QString::fromUtf8("actionChiudi"));
        actionEsporta_CSV = new QAction(MainWindow);
        actionEsporta_CSV->setObjectName(QString::fromUtf8("actionEsporta_CSV"));
        actionScarico = new QAction(MainWindow);
        actionScarico->setObjectName(QString::fromUtf8("actionScarico"));
        actionExe = new QAction(MainWindow);
        actionExe->setObjectName(QString::fromUtf8("actionExe"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setEnabled(true);
        centralwidget->setAutoFillBackground(false);
        TabWidget = new QTabWidget(centralwidget);
        TabWidget->setObjectName(QString::fromUtf8("TabWidget"));
        TabWidget->setGeometry(QRect(260, 40, 251, 481));
        Tab1 = new QWidget();
        Tab1->setObjectName(QString::fromUtf8("Tab1"));
        Tab1->setAcceptDrops(true);
        layoutWidget = new QWidget(Tab1);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 20, 201, 421));
        gridLay1 = new QGridLayout(layoutWidget);
        gridLay1->setObjectName(QString::fromUtf8("gridLay1"));
        gridLay1->setContentsMargins(0, 0, 0, 0);
        cella11 = new QWidget(layoutWidget);
        cella11->setObjectName(QString::fromUtf8("cella11"));
        cella11->setMouseTracking(true);
        cella11->setAcceptDrops(true);

        gridLay1->addWidget(cella11, 5, 1, 1, 1);

        cella3 = new QWidget(layoutWidget);
        cella3->setObjectName(QString::fromUtf8("cella3"));
        cella3->setEnabled(true);
        cella3->setMouseTracking(true);
        cella3->setAcceptDrops(true);

        gridLay1->addWidget(cella3, 1, 1, 1, 1);

        cella6 = new QWidget(layoutWidget);
        cella6->setObjectName(QString::fromUtf8("cella6"));
        cella6->setMouseTracking(true);
        cella6->setAcceptDrops(true);

        gridLay1->addWidget(cella6, 3, 0, 1, 1);

        cella1 = new QWidget(layoutWidget);
        cella1->setObjectName(QString::fromUtf8("cella1"));
        cella1->setMouseTracking(true);
        cella1->setAcceptDrops(true);

        gridLay1->addWidget(cella1, 0, 1, 1, 1);

        cella2 = new QWidget(layoutWidget);
        cella2->setObjectName(QString::fromUtf8("cella2"));
        cella2->setMouseTracking(true);
        cella2->setAcceptDrops(true);

        gridLay1->addWidget(cella2, 1, 0, 1, 1);

        cella10 = new QWidget(layoutWidget);
        cella10->setObjectName(QString::fromUtf8("cella10"));
        cella10->setMouseTracking(true);
        cella10->setAcceptDrops(true);

        gridLay1->addWidget(cella10, 5, 0, 1, 1);

        cella4 = new QWidget(layoutWidget);
        cella4->setObjectName(QString::fromUtf8("cella4"));
        cella4->setMouseTracking(true);
        cella4->setAcceptDrops(true);

        gridLay1->addWidget(cella4, 2, 0, 1, 1);

        cella8 = new QWidget(layoutWidget);
        cella8->setObjectName(QString::fromUtf8("cella8"));
        cella8->setMouseTracking(true);
        cella8->setAcceptDrops(true);

        gridLay1->addWidget(cella8, 4, 0, 1, 1);

        cella5 = new QWidget(layoutWidget);
        cella5->setObjectName(QString::fromUtf8("cella5"));
        cella5->setMouseTracking(true);
        cella5->setAcceptDrops(true);

        gridLay1->addWidget(cella5, 2, 1, 1, 1);

        cella7 = new QWidget(layoutWidget);
        cella7->setObjectName(QString::fromUtf8("cella7"));
        cella7->setMouseTracking(true);
        cella7->setAcceptDrops(true);

        gridLay1->addWidget(cella7, 3, 1, 1, 1);

        cella9 = new QWidget(layoutWidget);
        cella9->setObjectName(QString::fromUtf8("cella9"));
        cella9->setMouseTracking(true);
        cella9->setAcceptDrops(true);

        gridLay1->addWidget(cella9, 4, 1, 1, 1);

        cella0 = new QWidget(layoutWidget);
        cella0->setObjectName(QString::fromUtf8("cella0"));
        cella0->setMouseTracking(true);
        cella0->setAcceptDrops(true);

        gridLay1->addWidget(cella0, 0, 0, 1, 1);

        TabWidget->addTab(Tab1, QString());
        Tab2 = new QWidget();
        Tab2->setObjectName(QString::fromUtf8("Tab2"));
        layoutWidget_2 = new QWidget(Tab2);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(20, 20, 201, 421));
        gridLay2 = new QGridLayout(layoutWidget_2);
        gridLay2->setObjectName(QString::fromUtf8("gridLay2"));
        gridLay2->setContentsMargins(0, 0, 0, 0);
        cella11_2 = new QWidget(layoutWidget_2);
        cella11_2->setObjectName(QString::fromUtf8("cella11_2"));
        cella11_2->setMouseTracking(true);
        cella11_2->setAcceptDrops(true);

        gridLay2->addWidget(cella11_2, 5, 1, 1, 1);

        cella3_2 = new QWidget(layoutWidget_2);
        cella3_2->setObjectName(QString::fromUtf8("cella3_2"));
        cella3_2->setMouseTracking(true);
        cella3_2->setAcceptDrops(true);

        gridLay2->addWidget(cella3_2, 1, 1, 1, 1);

        cella6_2 = new QWidget(layoutWidget_2);
        cella6_2->setObjectName(QString::fromUtf8("cella6_2"));
        cella6_2->setMouseTracking(true);
        cella6_2->setAcceptDrops(true);

        gridLay2->addWidget(cella6_2, 3, 0, 1, 1);

        cella1_2 = new QWidget(layoutWidget_2);
        cella1_2->setObjectName(QString::fromUtf8("cella1_2"));
        cella1_2->setMouseTracking(true);
        cella1_2->setAcceptDrops(true);

        gridLay2->addWidget(cella1_2, 0, 1, 1, 1);

        cella2_2 = new QWidget(layoutWidget_2);
        cella2_2->setObjectName(QString::fromUtf8("cella2_2"));
        cella2_2->setMouseTracking(true);
        cella2_2->setAcceptDrops(true);

        gridLay2->addWidget(cella2_2, 1, 0, 1, 1);

        cella10_2 = new QWidget(layoutWidget_2);
        cella10_2->setObjectName(QString::fromUtf8("cella10_2"));
        cella10_2->setMouseTracking(true);
        cella10_2->setAcceptDrops(true);

        gridLay2->addWidget(cella10_2, 5, 0, 1, 1);

        cella0_2 = new QWidget(layoutWidget_2);
        cella0_2->setObjectName(QString::fromUtf8("cella0_2"));
        cella0_2->setMouseTracking(true);
        cella0_2->setTabletTracking(false);
        cella0_2->setAcceptDrops(true);

        gridLay2->addWidget(cella0_2, 0, 0, 1, 1);

        cella4_2 = new QWidget(layoutWidget_2);
        cella4_2->setObjectName(QString::fromUtf8("cella4_2"));
        cella4_2->setMouseTracking(true);
        cella4_2->setAcceptDrops(true);

        gridLay2->addWidget(cella4_2, 2, 0, 1, 1);

        cella8_2 = new QWidget(layoutWidget_2);
        cella8_2->setObjectName(QString::fromUtf8("cella8_2"));
        cella8_2->setMouseTracking(true);
        cella8_2->setAcceptDrops(true);

        gridLay2->addWidget(cella8_2, 4, 0, 1, 1);

        cella5_2 = new QWidget(layoutWidget_2);
        cella5_2->setObjectName(QString::fromUtf8("cella5_2"));
        cella5_2->setMouseTracking(true);
        cella5_2->setAcceptDrops(true);

        gridLay2->addWidget(cella5_2, 2, 1, 1, 1);

        cella7_2 = new QWidget(layoutWidget_2);
        cella7_2->setObjectName(QString::fromUtf8("cella7_2"));
        cella7_2->setMouseTracking(true);
        cella7_2->setAcceptDrops(true);

        gridLay2->addWidget(cella7_2, 3, 1, 1, 1);

        cella9_2 = new QWidget(layoutWidget_2);
        cella9_2->setObjectName(QString::fromUtf8("cella9_2"));
        cella9_2->setMouseTracking(true);
        cella9_2->setAcceptDrops(true);

        gridLay2->addWidget(cella9_2, 4, 1, 1, 1);

        TabWidget->addTab(Tab2, QString());
        Tab3 = new QWidget();
        Tab3->setObjectName(QString::fromUtf8("Tab3"));
        layoutWidget_3 = new QWidget(Tab3);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(20, 20, 201, 421));
        gridLay3 = new QGridLayout(layoutWidget_3);
        gridLay3->setObjectName(QString::fromUtf8("gridLay3"));
        gridLay3->setContentsMargins(0, 0, 0, 0);
        cella11_3 = new QWidget(layoutWidget_3);
        cella11_3->setObjectName(QString::fromUtf8("cella11_3"));
        cella11_3->setMouseTracking(true);
        cella11_3->setAcceptDrops(true);

        gridLay3->addWidget(cella11_3, 5, 1, 1, 1);

        cella3_3 = new QWidget(layoutWidget_3);
        cella3_3->setObjectName(QString::fromUtf8("cella3_3"));
        cella3_3->setMouseTracking(true);
        cella3_3->setAcceptDrops(true);

        gridLay3->addWidget(cella3_3, 1, 1, 1, 1);

        cella6_3 = new QWidget(layoutWidget_3);
        cella6_3->setObjectName(QString::fromUtf8("cella6_3"));
        cella6_3->setMouseTracking(true);
        cella6_3->setAcceptDrops(true);

        gridLay3->addWidget(cella6_3, 3, 0, 1, 1);

        cella1_3 = new QWidget(layoutWidget_3);
        cella1_3->setObjectName(QString::fromUtf8("cella1_3"));
        cella1_3->setMouseTracking(true);
        cella1_3->setAcceptDrops(true);

        gridLay3->addWidget(cella1_3, 0, 1, 1, 1);

        cella2_3 = new QWidget(layoutWidget_3);
        cella2_3->setObjectName(QString::fromUtf8("cella2_3"));
        cella2_3->setMouseTracking(true);
        cella2_3->setAcceptDrops(true);

        gridLay3->addWidget(cella2_3, 1, 0, 1, 1);

        cella10_3 = new QWidget(layoutWidget_3);
        cella10_3->setObjectName(QString::fromUtf8("cella10_3"));
        cella10_3->setMouseTracking(true);
        cella10_3->setAcceptDrops(true);

        gridLay3->addWidget(cella10_3, 5, 0, 1, 1);

        cella0_3 = new QWidget(layoutWidget_3);
        cella0_3->setObjectName(QString::fromUtf8("cella0_3"));
        cella0_3->setMouseTracking(true);
        cella0_3->setTabletTracking(false);
        cella0_3->setAcceptDrops(true);

        gridLay3->addWidget(cella0_3, 0, 0, 1, 1);

        cella4_3 = new QWidget(layoutWidget_3);
        cella4_3->setObjectName(QString::fromUtf8("cella4_3"));
        cella4_3->setMouseTracking(true);
        cella4_3->setAcceptDrops(true);

        gridLay3->addWidget(cella4_3, 2, 0, 1, 1);

        cella8_3 = new QWidget(layoutWidget_3);
        cella8_3->setObjectName(QString::fromUtf8("cella8_3"));
        cella8_3->setMouseTracking(true);
        cella8_3->setAcceptDrops(true);

        gridLay3->addWidget(cella8_3, 4, 0, 1, 1);

        cella5_3 = new QWidget(layoutWidget_3);
        cella5_3->setObjectName(QString::fromUtf8("cella5_3"));
        cella5_3->setMouseTracking(true);
        cella5_3->setAcceptDrops(true);

        gridLay3->addWidget(cella5_3, 2, 1, 1, 1);

        cella7_3 = new QWidget(layoutWidget_3);
        cella7_3->setObjectName(QString::fromUtf8("cella7_3"));
        cella7_3->setMouseTracking(true);
        cella7_3->setAcceptDrops(true);

        gridLay3->addWidget(cella7_3, 3, 1, 1, 1);

        cella9_3 = new QWidget(layoutWidget_3);
        cella9_3->setObjectName(QString::fromUtf8("cella9_3"));
        cella9_3->setMouseTracking(true);
        cella9_3->setAcceptDrops(true);

        gridLay3->addWidget(cella9_3, 4, 1, 1, 1);

        TabWidget->addTab(Tab3, QString());
        Tab4 = new QWidget();
        Tab4->setObjectName(QString::fromUtf8("Tab4"));
        layoutWidget_4 = new QWidget(Tab4);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(20, 20, 201, 421));
        gridLay4 = new QGridLayout(layoutWidget_4);
        gridLay4->setObjectName(QString::fromUtf8("gridLay4"));
        gridLay4->setContentsMargins(0, 0, 0, 0);
        cella11_4 = new QWidget(layoutWidget_4);
        cella11_4->setObjectName(QString::fromUtf8("cella11_4"));
        cella11_4->setMouseTracking(true);
        cella11_4->setAcceptDrops(true);

        gridLay4->addWidget(cella11_4, 5, 1, 1, 1);

        cella3_4 = new QWidget(layoutWidget_4);
        cella3_4->setObjectName(QString::fromUtf8("cella3_4"));
        cella3_4->setMouseTracking(true);
        cella3_4->setAcceptDrops(true);

        gridLay4->addWidget(cella3_4, 1, 1, 1, 1);

        cella6_4 = new QWidget(layoutWidget_4);
        cella6_4->setObjectName(QString::fromUtf8("cella6_4"));
        cella6_4->setMouseTracking(true);
        cella6_4->setAcceptDrops(true);

        gridLay4->addWidget(cella6_4, 3, 0, 1, 1);

        cella1_4 = new QWidget(layoutWidget_4);
        cella1_4->setObjectName(QString::fromUtf8("cella1_4"));
        cella1_4->setMouseTracking(true);
        cella1_4->setAcceptDrops(true);

        gridLay4->addWidget(cella1_4, 0, 1, 1, 1);

        cella2_4 = new QWidget(layoutWidget_4);
        cella2_4->setObjectName(QString::fromUtf8("cella2_4"));
        cella2_4->setMouseTracking(true);
        cella2_4->setAcceptDrops(true);

        gridLay4->addWidget(cella2_4, 1, 0, 1, 1);

        cella10_4 = new QWidget(layoutWidget_4);
        cella10_4->setObjectName(QString::fromUtf8("cella10_4"));
        cella10_4->setMouseTracking(true);
        cella10_4->setAcceptDrops(true);

        gridLay4->addWidget(cella10_4, 5, 0, 1, 1);

        cella0_4 = new QWidget(layoutWidget_4);
        cella0_4->setObjectName(QString::fromUtf8("cella0_4"));
        cella0_4->setMouseTracking(true);
        cella0_4->setTabletTracking(false);
        cella0_4->setAcceptDrops(true);

        gridLay4->addWidget(cella0_4, 0, 0, 1, 1);

        cella4_4 = new QWidget(layoutWidget_4);
        cella4_4->setObjectName(QString::fromUtf8("cella4_4"));
        cella4_4->setMouseTracking(true);
        cella4_4->setAcceptDrops(true);

        gridLay4->addWidget(cella4_4, 2, 0, 1, 1);

        cella8_4 = new QWidget(layoutWidget_4);
        cella8_4->setObjectName(QString::fromUtf8("cella8_4"));
        cella8_4->setMouseTracking(true);
        cella8_4->setAcceptDrops(true);

        gridLay4->addWidget(cella8_4, 4, 0, 1, 1);

        cella5_4 = new QWidget(layoutWidget_4);
        cella5_4->setObjectName(QString::fromUtf8("cella5_4"));
        cella5_4->setMouseTracking(true);
        cella5_4->setAcceptDrops(true);

        gridLay4->addWidget(cella5_4, 2, 1, 1, 1);

        cella7_4 = new QWidget(layoutWidget_4);
        cella7_4->setObjectName(QString::fromUtf8("cella7_4"));
        cella7_4->setMouseTracking(true);
        cella7_4->setAcceptDrops(true);

        gridLay4->addWidget(cella7_4, 3, 1, 1, 1);

        cella9_4 = new QWidget(layoutWidget_4);
        cella9_4->setObjectName(QString::fromUtf8("cella9_4"));
        cella9_4->setMouseTracking(true);
        cella9_4->setAcceptDrops(true);

        gridLay4->addWidget(cella9_4, 4, 1, 1, 1);

        TabWidget->addTab(Tab4, QString());
        Tab5 = new QWidget();
        Tab5->setObjectName(QString::fromUtf8("Tab5"));
        layoutWidget_5 = new QWidget(Tab5);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(20, 20, 201, 421));
        gridLay5 = new QGridLayout(layoutWidget_5);
        gridLay5->setObjectName(QString::fromUtf8("gridLay5"));
        gridLay5->setContentsMargins(0, 0, 0, 0);
        cella11_5 = new QWidget(layoutWidget_5);
        cella11_5->setObjectName(QString::fromUtf8("cella11_5"));
        cella11_5->setMouseTracking(true);
        cella11_5->setAcceptDrops(true);

        gridLay5->addWidget(cella11_5, 5, 1, 1, 1);

        cella3_5 = new QWidget(layoutWidget_5);
        cella3_5->setObjectName(QString::fromUtf8("cella3_5"));
        cella3_5->setMouseTracking(true);
        cella3_5->setAcceptDrops(true);

        gridLay5->addWidget(cella3_5, 1, 1, 1, 1);

        cella6_5 = new QWidget(layoutWidget_5);
        cella6_5->setObjectName(QString::fromUtf8("cella6_5"));
        cella6_5->setMouseTracking(true);
        cella6_5->setAcceptDrops(true);

        gridLay5->addWidget(cella6_5, 3, 0, 1, 1);

        cella1_5 = new QWidget(layoutWidget_5);
        cella1_5->setObjectName(QString::fromUtf8("cella1_5"));
        cella1_5->setMouseTracking(true);
        cella1_5->setAcceptDrops(true);

        gridLay5->addWidget(cella1_5, 0, 1, 1, 1);

        cella2_5 = new QWidget(layoutWidget_5);
        cella2_5->setObjectName(QString::fromUtf8("cella2_5"));
        cella2_5->setMouseTracking(true);
        cella2_5->setAcceptDrops(true);

        gridLay5->addWidget(cella2_5, 1, 0, 1, 1);

        cella10_5 = new QWidget(layoutWidget_5);
        cella10_5->setObjectName(QString::fromUtf8("cella10_5"));
        cella10_5->setMouseTracking(true);
        cella10_5->setAcceptDrops(true);

        gridLay5->addWidget(cella10_5, 5, 0, 1, 1);

        cella0_5 = new QWidget(layoutWidget_5);
        cella0_5->setObjectName(QString::fromUtf8("cella0_5"));
        cella0_5->setMouseTracking(true);
        cella0_5->setTabletTracking(false);
        cella0_5->setAcceptDrops(true);

        gridLay5->addWidget(cella0_5, 0, 0, 1, 1);

        cella4_5 = new QWidget(layoutWidget_5);
        cella4_5->setObjectName(QString::fromUtf8("cella4_5"));
        cella4_5->setMouseTracking(true);
        cella4_5->setAcceptDrops(true);

        gridLay5->addWidget(cella4_5, 2, 0, 1, 1);

        cella8_5 = new QWidget(layoutWidget_5);
        cella8_5->setObjectName(QString::fromUtf8("cella8_5"));
        cella8_5->setMouseTracking(true);
        cella8_5->setAcceptDrops(true);

        gridLay5->addWidget(cella8_5, 4, 0, 1, 1);

        cella5_5 = new QWidget(layoutWidget_5);
        cella5_5->setObjectName(QString::fromUtf8("cella5_5"));
        cella5_5->setMouseTracking(true);
        cella5_5->setAcceptDrops(true);

        gridLay5->addWidget(cella5_5, 2, 1, 1, 1);

        cella7_5 = new QWidget(layoutWidget_5);
        cella7_5->setObjectName(QString::fromUtf8("cella7_5"));
        cella7_5->setMouseTracking(true);
        cella7_5->setAcceptDrops(true);

        gridLay5->addWidget(cella7_5, 3, 1, 1, 1);

        cella9_5 = new QWidget(layoutWidget_5);
        cella9_5->setObjectName(QString::fromUtf8("cella9_5"));
        cella9_5->setMouseTracking(true);
        cella9_5->setAcceptDrops(true);

        gridLay5->addWidget(cella9_5, 4, 1, 1, 1);

        TabWidget->addTab(Tab5, QString());
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(530, 190, 251, 321));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        layoutWidget1 = new QWidget(frame);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(0, 0, 251, 321));
        gridLayFra = new QGridLayout(layoutWidget1);
        gridLayFra->setObjectName(QString::fromUtf8("gridLayFra"));
        gridLayFra->setContentsMargins(0, 0, 0, 0);
        comboBox_6 = new QComboBox(layoutWidget1);
        comboBox_6->addItem(QString());
        comboBox_6->addItem(QString());
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));

        gridLayFra->addWidget(comboBox_6, 7, 2, 1, 1);

        label_6 = new QLabel(layoutWidget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayFra->addWidget(label_6, 5, 1, 1, 1);

        comboBox_2 = new QComboBox(layoutWidget1);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        gridLayFra->addWidget(comboBox_2, 3, 2, 1, 1);

        label_10 = new QLabel(layoutWidget1);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayFra->addWidget(label_10, 9, 1, 1, 1);

        label_8 = new QLabel(layoutWidget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayFra->addWidget(label_8, 7, 1, 1, 1);

        label_3 = new QLabel(layoutWidget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayFra->addWidget(label_3, 2, 1, 1, 1);

        label_2 = new QLabel(layoutWidget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayFra->addWidget(label_2, 1, 1, 1, 1);

        label_4 = new QLabel(layoutWidget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayFra->addWidget(label_4, 3, 1, 1, 1);

        comboBox_8 = new QComboBox(layoutWidget1);
        comboBox_8->addItem(QString());
        comboBox_8->addItem(QString());
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));

        gridLayFra->addWidget(comboBox_8, 9, 2, 1, 1);

        comboBox_9 = new QComboBox(layoutWidget1);
        comboBox_9->addItem(QString());
        comboBox_9->addItem(QString());
        comboBox_9->setObjectName(QString::fromUtf8("comboBox_9"));

        gridLayFra->addWidget(comboBox_9, 10, 2, 1, 1);

        comboBox_5 = new QComboBox(layoutWidget1);
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->addItem(QString());
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        gridLayFra->addWidget(comboBox_5, 6, 2, 1, 1);

        label_5 = new QLabel(layoutWidget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayFra->addWidget(label_5, 4, 1, 1, 1);

        comboBox_3 = new QComboBox(layoutWidget1);
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        gridLayFra->addWidget(comboBox_3, 4, 2, 1, 1);

        comboBox = new QComboBox(layoutWidget1);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setInsertPolicy(QComboBox::InsertAfterCurrent);
        comboBox->setSizeAdjustPolicy(QComboBox::AdjustToContents);

        gridLayFra->addWidget(comboBox, 2, 2, 1, 1);

        label_12 = new QLabel(layoutWidget1);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayFra->addWidget(label_12, 1, 2, 1, 1);

        label_7 = new QLabel(layoutWidget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayFra->addWidget(label_7, 6, 1, 1, 1);

        label_13 = new QLabel(layoutWidget1);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayFra->addWidget(label_13, 0, 2, 1, 1);

        label_9 = new QLabel(layoutWidget1);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayFra->addWidget(label_9, 8, 1, 1, 1);

        comboBox_4 = new QComboBox(layoutWidget1);
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        gridLayFra->addWidget(comboBox_4, 5, 2, 1, 1);

        label = new QLabel(layoutWidget1);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayFra->addWidget(label, 0, 1, 1, 1);

        comboBox_7 = new QComboBox(layoutWidget1);
        comboBox_7->addItem(QString());
        comboBox_7->addItem(QString());
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));

        gridLayFra->addWidget(comboBox_7, 8, 2, 1, 1);

        label_11 = new QLabel(layoutWidget1);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayFra->addWidget(label_11, 10, 1, 1, 1);

        scrollArea = new QScrollArea(centralwidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(20, 40, 221, 471));
        scrollArea->setWidgetResizable(true);
        scrollContents = new QWidget();
        scrollContents->setObjectName(QString::fromUtf8("scrollContents"));
        scrollContents->setGeometry(QRect(0, 0, 219, 469));
        scrollContents->setMouseTracking(true);
        scrollArea->setWidget(scrollContents);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(790, 490, 80, 24));
        MainWindow->setCentralWidget(centralwidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1218, 21));
        menumenu = new QMenu(menuBar);
        menumenu->setObjectName(QString::fromUtf8("menumenu"));
        menuOUT = new QMenu(menuBar);
        menuOUT->setObjectName(QString::fromUtf8("menuOUT"));
        menuCUT = new QMenu(menuBar);
        menuCUT->setObjectName(QString::fromUtf8("menuCUT"));
        menuUsb = new QMenu(menuBar);
        menuUsb->setObjectName(QString::fromUtf8("menuUsb"));
        MainWindow->setMenuBar(menuBar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, toolBar);

        menuBar->addAction(menumenu->menuAction());
        menuBar->addAction(menuOUT->menuAction());
        menuBar->addAction(menuCUT->menuAction());
        menuBar->addAction(menuUsb->menuAction());
        menumenu->addAction(actionSalva_tutto);
        menumenu->addAction(actionNuovo);
        menumenu->addAction(actionChiudi);
        menuOUT->addAction(actionScarico);
        menuCUT->addAction(actionExe);
        menuUsb->addAction(actionEsporta_CSV);

        retranslateUi(MainWindow);

        TabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionSalva_tutto->setText(QCoreApplication::translate("MainWindow", "Salva_Configurazione", nullptr));
        actionNuovo->setText(QCoreApplication::translate("MainWindow", "Nuovo", nullptr));
        actionChiudi->setText(QCoreApplication::translate("MainWindow", "Chiudi", nullptr));
        actionEsporta_CSV->setText(QCoreApplication::translate("MainWindow", "Esporta CSV", nullptr));
        actionScarico->setText(QCoreApplication::translate("MainWindow", "Scarico", nullptr));
        actionExe->setText(QCoreApplication::translate("MainWindow", "Exe", nullptr));
        TabWidget->setTabText(TabWidget->indexOf(Tab1), QCoreApplication::translate("MainWindow", "Tab1", nullptr));
        TabWidget->setTabText(TabWidget->indexOf(Tab2), QCoreApplication::translate("MainWindow", "Tab2", nullptr));
        TabWidget->setTabText(TabWidget->indexOf(Tab3), QCoreApplication::translate("MainWindow", "Tab3", nullptr));
        TabWidget->setTabText(TabWidget->indexOf(Tab4), QCoreApplication::translate("MainWindow", "Tab4", nullptr));
        TabWidget->setTabText(TabWidget->indexOf(Tab5), QCoreApplication::translate("MainWindow", "Tab5", nullptr));
        comboBox_6->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_6->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));

        label_6->setText(QCoreApplication::translate("MainWindow", " OUT_3", nullptr));
        comboBox_2->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_2->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox_2->setItemText(2, QCoreApplication::translate("MainWindow", "2", nullptr));
        comboBox_2->setItemText(3, QCoreApplication::translate("MainWindow", "3", nullptr));
        comboBox_2->setItemText(4, QCoreApplication::translate("MainWindow", "4", nullptr));
        comboBox_2->setItemText(5, QCoreApplication::translate("MainWindow", "5", nullptr));

        label_10->setText(QCoreApplication::translate("MainWindow", " TASTO CONSENSO", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", " STOP", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", " AZIONE", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", " ICONA TASTO N\302\260", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", " OUT", nullptr));
        comboBox_8->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_8->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));

        comboBox_9->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_9->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));

        comboBox_5->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_5->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox_5->setItemText(2, QCoreApplication::translate("MainWindow", "2", nullptr));
        comboBox_5->setItemText(3, QCoreApplication::translate("MainWindow", "3", nullptr));
        comboBox_5->setItemText(4, QCoreApplication::translate("MainWindow", "4", nullptr));
        comboBox_5->setItemText(5, QCoreApplication::translate("MainWindow", "5", nullptr));
        comboBox_5->setItemText(6, QCoreApplication::translate("MainWindow", "6", nullptr));
        comboBox_5->setItemText(7, QCoreApplication::translate("MainWindow", "7", nullptr));

        label_5->setText(QCoreApplication::translate("MainWindow", " OUT_2", nullptr));
        comboBox_3->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_3->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox_3->setItemText(2, QCoreApplication::translate("MainWindow", "2", nullptr));
        comboBox_3->setItemText(3, QCoreApplication::translate("MainWindow", "3", nullptr));
        comboBox_3->setItemText(4, QCoreApplication::translate("MainWindow", "4", nullptr));
        comboBox_3->setItemText(5, QCoreApplication::translate("MainWindow", "5", nullptr));

        comboBox->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("MainWindow", "2", nullptr));

        label_12->setText(QCoreApplication::translate("MainWindow", "//", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", " OUT_4", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "CONFIGURAZIONE:", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", " STOP_2", nullptr));
        comboBox_4->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_4->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));
        comboBox_4->setItemText(2, QCoreApplication::translate("MainWindow", "2", nullptr));
        comboBox_4->setItemText(3, QCoreApplication::translate("MainWindow", "3", nullptr));
        comboBox_4->setItemText(4, QCoreApplication::translate("MainWindow", "4", nullptr));
        comboBox_4->setItemText(5, QCoreApplication::translate("MainWindow", "5", nullptr));
        comboBox_4->setItemText(6, QCoreApplication::translate("MainWindow", "6", nullptr));
        comboBox_4->setItemText(7, QCoreApplication::translate("MainWindow", "7", nullptr));

        label->setText(QCoreApplication::translate("MainWindow", "MENU' TASTO :", nullptr));
        comboBox_7->setItemText(0, QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_7->setItemText(1, QCoreApplication::translate("MainWindow", "1", nullptr));

        label_11->setText(QCoreApplication::translate("MainWindow", " SICUREZZA", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "PushButton1", nullptr));
        menumenu->setTitle(QCoreApplication::translate("MainWindow", "FILE", nullptr));
        menuOUT->setTitle(QCoreApplication::translate("MainWindow", "OUT", nullptr));
        menuCUT->setTitle(QCoreApplication::translate("MainWindow", "CUT", nullptr));
        menuUsb->setTitle(QCoreApplication::translate("MainWindow", "Usb", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("MainWindow", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
