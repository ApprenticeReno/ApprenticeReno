#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QListWidgetItem>
#include <QHBoxLayout>
#include <QDrag>
#include <QIcon>
#include <QPushButton>
#include <QMessageBox>
#include <QListWidgetItem>
#include <QList>
#include <QLayout>
#include <QMouseEvent>
#include <QAction>
#include <QCoreApplication>
#include <QMouseEvent>
#include <QPainter>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
   ui->setupUi(this);
   setAcceptDrops(true);
   setWindowTitle("Teleref_Smart_PTM_prototipoR1");

   auto *gridLay=new QGridLayout(); //grid layout per i bottoni

   auto *btn0=new QPushButton("ic0");
   btn0->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn0->setIconSize(QSize(50,50));
  // btn0->dragMoveEvent();

   auto *btn1=new QPushButton("ic1");
   btn1->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn1->setIconSize(QSize(50,50));

   auto *btn2=new QPushButton("ic2");
   btn2->setIcon(QIcon(":/pix/images/key_LATO_DESTRO_GIU.png"));
   btn2->setIconSize(QSize(50,50));

   auto *btn3=new QPushButton("ic3");
   btn3->setIcon(QIcon(":/pix/images/key_LATO_DESTRO_SU.png"));
   btn3->setIconSize(QSize(50,50));

   auto *btn4=new QPushButton("ic4");
   btn4->setIcon(QIcon(":/pix/images/key_LEVA_GETTO_OFF.png"));
   btn4->setIconSize(QSize(50,50));

   auto *btn5=new QPushButton("ic5");
   btn5->setIcon(QIcon(":/pix/images/key_LEVA_GETTO_ON.png"));
   btn5->setIconSize(QSize(50,50));

   auto *btn6=new QPushButton("ic6");
   btn6->setIcon(QIcon(":/pix/images/key_PORTELLA_ENTRA.png"));
   btn6->setIconSize(QSize(50,50));

   auto *btn7=new QPushButton("ic7");
   btn7->setIcon(QIcon(":/pix/images/key_PORTELLA_ESCE.png"));
   btn7->setIconSize(QSize(50,50));

   auto *btn8=new QPushButton("ic8");
   btn8->setIcon(QIcon(":/pix/images/key_PORTELLA_RUOTA_A_DX.png"));
   btn8->setIconSize(QSize(50,50));

   auto *btn9=new QPushButton("ic9");
   btn9->setIcon(QIcon(":/pix/images/key_PORTELLA_RUOTA_A_SX.png"));
   btn9->setIconSize(QSize(50,50));

   auto *btn10=new QPushButton("ic10");
   btn10->setIcon(QIcon(":/pix/images/key_POSTERIORE_GIU.png"));
   btn10->setIconSize(QSize(50,50));

   auto *btn11=new QPushButton("ic11");
   btn11->setIcon(QIcon(":/pix/images/key_POSTERIORE_SU.png"));
   btn11->setIconSize(QSize(50,50));

   auto *btn12=new QPushButton("ic12");
   btn12->setIcon(QIcon(":/pix/images/key_RUOTA_DX_GIU.png"));
   btn12->setIconSize(QSize(50,50));

   auto *btn13=new QPushButton("ic13");
   btn13->setIcon(QIcon(":/pix/images/key_RUOTA_DX_SU.png"));
   btn13->setIconSize(QSize(50,50));

   auto *btn14=new QPushButton("ic14");
   btn14->setIcon(QIcon(":/pix/images/key_RUOTA_SX_GIU.png"));
   btn14->setIconSize(QSize(50,50));

   auto *btn15=new QPushButton("ic15");
   btn15->setIcon(QIcon(":/pix/images/key_RUOTA_SX_SU.png"));
   btn15->setIconSize(QSize(50,50));


      gridLay->addWidget(btn0,0,0); //aggiunta bottone-icona al grid layout
      gridLay->addWidget(btn1,0,1);
      gridLay->addWidget(btn2,1,0);
      gridLay->addWidget(btn3,1,1);
      gridLay->addWidget(btn4,2,0);
      gridLay->addWidget(btn5,2,1);
      gridLay->addWidget(btn6,3,0);
      gridLay->addWidget(btn7,3,1);
      gridLay->addWidget(btn8,4,0);
      gridLay->addWidget(btn9,4,1);
      gridLay->addWidget(btn10,5,0);
      gridLay->addWidget(btn11,5,1);
      gridLay->addWidget(btn12,6,0);
      gridLay->addWidget(btn13,6,1);
      gridLay->addWidget(btn14,7,0);
      gridLay->addWidget(btn15,7,1);

   ui->scrollContents->setLayout(gridLay); // layout contenuto scroll area

   ui->frame->setStyleSheet("border :0.5px solid black"); //brodo frame configurazione tasto

  //connessione bottone funzione
  connect(btn0,SIGNAL(clicked()),this,SLOT(on_btn0_clicked()));
  connect(btn1,SIGNAL(clicked()),this,SLOT(on_btn1_clicked()));
  connect(btn2,SIGNAL(clicked()),this,SLOT(on_btn2_clicked()));
  connect(btn3,SIGNAL(clicked()),this,SLOT(on_btn3_clicked()));
  connect(btn4,SIGNAL(clicked()),this,SLOT(on_btn4_clicked()));
  connect(btn5,SIGNAL(clicked()),this,SLOT(on_btn5_clicked()));
  connect(btn6,SIGNAL(clicked()),this,SLOT(on_btn6_clicked()));

  ui->scrollArea->setAcceptDrops(false);

  ui->TabWidget->setAcceptDrops(true);

}


//FUNZIONI SETTAGGIO CONFIGURAZIONE A BOTTONE ICONA ---------------------------------------------------------------------------
void MainWindow::on_btn0_clicked(){

ui->label_12->setText(QString(" 0 -> Barra_giu"));

}

void MainWindow::on_btn1_clicked(){
    ui->label_12->setText(QString(" 1 -> Barra_Su")); //set text icone
    ui->comboBox->currentText().isNull();
}

void MainWindow::on_btn2_clicked(){
    ui->label_12->setText(QString(" 2 -> Lato DX_GIU "));
}

void MainWindow::on_btn3_clicked(){
    ui->label_12->setText(QString(" 3 -> Lato DX_SU "));
}

void MainWindow::on_btn4_clicked(){
    ui->label_12->setText(QString(" 4 -> LEVA_GETTO_OFF "));
}

void MainWindow::on_btn5_clicked(){
    ui->label_12->setText(QString(" 5 -> LEVA_GETTO_ON "));
}

void MainWindow::on_btn6_clicked(){
    ui->label_12->setText(QString(" 6 -> PORTELLA_ENTRA "));
}

//FUNZIONI MENU ------------------------------------------------------------------------------------------------------------------
void MainWindow::on_actionSalva_tutto_triggered()
{
 //save all to file
}

void MainWindow::on_actionChiudi_triggered()
{
   close();
}

void MainWindow::on_actionEsporta_CSV_triggered()
{
  //open e write file
}

void MainWindow::on_actionNuovo_triggered()


{
 //();
}

//-----------------------------------------------------------------------------
void MainWindow::on_pushButton_clicked()
{
   qDebug()<<" valore combo box "<<ui->comboBox_2->currentText();
}

