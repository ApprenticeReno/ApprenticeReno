#ifndef FILE_H
#define FILE_H


class file
{
public:
    file();
};

#endif // FILE_H
