#include "MainWindow.h"
#include "List.h"
#include "OpenGlWidget.h"
#include <QGridLayout>
#include <QMessageBox>
#include <QPushButton>
#include <QFile>
#include <QDebug>
#include <QRect>
#include <QPoint>
#include <QLabel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{

    auto *reset = new QPushButton("Reset");
    auto *button = new QPushButton("Scrivi");
    auto *widget = new QWidget(this); // finestra centrale
    auto *layoutMain = new QHBoxLayout(widget); // layout della finestra centrale
    auto *list = new List(this);
    auto *layoutGrid = new QGridLayout();

    //widget che conterranno le icone

   //   QPoint *p1=new QPoint(1,0);
    auto *Cella0 = new OpenGlWidget(this);
    auto *Cella1 = new OpenGlWidget(this); // OPEN GRID LAYOUT WIDGET
    auto *Cella2 = new OpenGlWidget(this);
    auto *Cella3 = new OpenGlWidget(this);
    auto *Cella4 = new OpenGlWidget(this);
    auto *Cella5 = new OpenGlWidget(this);
    auto *Cella6 = new OpenGlWidget(this);
    auto *Cella7 = new OpenGlWidget(this);
    auto *Cella8 = new OpenGlWidget(this);
    auto *Cella9 = new OpenGlWidget(this);
    auto *Cella10 = new OpenGlWidget(this);
    auto *Cella11 = new OpenGlWidget(this);
    auto *Cella12 = new OpenGlWidget(this);
    auto *Cella13 = new OpenGlWidget(this);
    auto *Cella14 = new OpenGlWidget(this);
    auto *Cella15 = new OpenGlWidget(this);
    auto *Cella16 = new OpenGlWidget(this);
    auto *Cella17 = new OpenGlWidget(this);
    auto *Cella18 = new OpenGlWidget(this);
    auto *Cella19 = new OpenGlWidget(this);

     layoutGrid->addWidget(Cella0,0,0);
     layoutGrid->addWidget(Cella1,0,1);
     layoutGrid->addWidget(Cella2,1,0);
     layoutGrid->addWidget(Cella3,1,1);
     layoutGrid->addWidget(Cella4,2,0);
     layoutGrid->addWidget(Cella5,2,1);
     layoutGrid->addWidget(Cella6,3,0);
     layoutGrid->addWidget(Cella7,3,1);
     layoutGrid->addWidget(Cella8,4,0);
     layoutGrid->addWidget(Cella9,4,1);
     layoutGrid->addWidget(Cella10,5,0);
     layoutGrid->addWidget(Cella11,5,1);
     layoutGrid->addWidget(Cella12,6,0);
     layoutGrid->addWidget(Cella13,6,1);
     layoutGrid->addWidget(Cella14,7,0);
     layoutGrid->addWidget(Cella15,7,1);
     layoutGrid->addWidget(Cella16,8,0);
     layoutGrid->addWidget(Cella17,8,1);
     layoutGrid->addWidget(Cella18,9,0);
     layoutGrid->addWidget(Cella19,9,1);

     //aggiunta bottoni
     layoutGrid->addWidget(reset,10,1,1,1);
     layoutGrid->addWidget(button,10,0,1,1);  //aggiunta bottone a fine grid layout


    // qDebug()<<" prova --> "<<layoutGrid->itemAtPosition(0,0);

     connect(button,SIGNAL(clicked()),this,SLOT(on_button_clicked())); // connessione tra : bottone - segnale click || finestra mainWindow - funzione slot on_button_clicked()

     connect(reset,SIGNAL(clicked()),this,SLOT(on_reset_clicked()));

     layoutMain->addWidget(list);
     layoutMain->addLayout(layoutGrid);

     setCentralWidget(widget);
     resize(400, 900);

     //aggiuntta icone alla lista ,path immagine , nome icona
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ko.png"),("item 0")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ko_big.png"), ("item 1 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ok.png"), ("item 2 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_PAGE.png"), ("item 3 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_MENU_ING.png"), ("item 4 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_MENU.png"), ("item 5 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_SU.png"), ("item 6 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_GIU.png"), ("item 7 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_B_SU.png"), ("item 8 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_B_ON_OFF.png"), ("item 9 ")));


         list->setViewMode(QListWidget::IconMode);
         list->setIconSize(QSize(28, 28));
         list->setGridSize(QSize(60, 60));
         list->setMaximumWidth(250);

}

// Funzione Scrivi al click del bottone
void MainWindow::on_button_clicked()
{
  //  QMessageBox::information(this,"Buongiorno","il file è stato scritto ");

    QFile file("myfile.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
            return;
        QTextStream out(&file);
        //out -esempio output per il txt che apre la funzione: NOME ICONA : "ITEM 1" NELLA "CELLA 1" IN RIGA 0 COLONNA 0
        file.close();
}

void MainWindow::on_reset_clicked(){ //RIDISEGNAMENTO TOTALE

    QMessageBox::information(this,"Ciao","Hai cliccato il tasto reset");

    auto *reset = new QPushButton("Reset");
    auto *button = new QPushButton("Scrivi");
    auto *widget = new QWidget(this); // finestra centrale
    auto *layoutMain = new QHBoxLayout(widget); // layout della finestra centrale
    auto *list = new List(this);
    auto *layoutGrid = new QGridLayout();

    auto *Cella0 = new OpenGlWidget(this); // OPEN GRID LAYOUT WIDGET
    auto *Cella1 = new OpenGlWidget(this);
    auto *Cella2 = new OpenGlWidget(this);
    auto *Cella3 = new OpenGlWidget(this);
    auto *Cella4 = new OpenGlWidget(this);
    auto *Cella5 = new OpenGlWidget(this);
    auto *Cella6 = new OpenGlWidget(this);
    auto *Cella7 = new OpenGlWidget(this);
    auto *Cella8 = new OpenGlWidget(this);
    auto *Cella9 = new OpenGlWidget(this);
    auto *Cella10 = new OpenGlWidget(this);
    auto *Cella11 = new OpenGlWidget(this);
    auto *Cella12 = new OpenGlWidget(this);
    auto *Cella13 = new OpenGlWidget(this);
    auto *Cella14 = new OpenGlWidget(this);
    auto *Cella15 = new OpenGlWidget(this);
    auto *Cella16 = new OpenGlWidget(this);
    auto *Cella17 = new OpenGlWidget(this);
    auto *Cella18 = new OpenGlWidget(this);
    auto *Cella19 = new OpenGlWidget(this);

     layoutGrid->addWidget(Cella0,0,0);
     layoutGrid->addWidget(Cella1,0,1);
     layoutGrid->addWidget(Cella2,1,0);
     layoutGrid->addWidget(Cella3,1,1);
     layoutGrid->addWidget(Cella4,2,0);
     layoutGrid->addWidget(Cella5,2,1);
     layoutGrid->addWidget(Cella6,3,0);
     layoutGrid->addWidget(Cella7,3,1);
     layoutGrid->addWidget(Cella8,4,0);
     layoutGrid->addWidget(Cella9,4,1);
     layoutGrid->addWidget(Cella10,5,0);
     layoutGrid->addWidget(Cella11,5,1);
     layoutGrid->addWidget(Cella12,6,0);
     layoutGrid->addWidget(Cella13,6,1);
     layoutGrid->addWidget(Cella14,7,0);
     layoutGrid->addWidget(Cella15,7,1);
     layoutGrid->addWidget(Cella16,8,0);
     layoutGrid->addWidget(Cella17,8,1);
     layoutGrid->addWidget(Cella18,9,0);
     layoutGrid->addWidget(Cella19,9,1);

     layoutGrid->addWidget(reset,10,1,1,1);
     layoutGrid->addWidget(button,10,0,1,1);  //aggiunta bottone a fine grid layout

      connect(button,SIGNAL(clicked()),this,SLOT(on_button_clicked())); // connessione tra : bottone - segnale click || finestra mainWindow - funzione slot on_button_clicked()

      connect(reset,SIGNAL(clicked()),this,SLOT(on_reset_clicked()));

     layoutMain->addWidget(list);
     layoutMain->addLayout(layoutGrid);

     setCentralWidget(widget);
     resize(400, 900);

     //path immagine , nome icona
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ko.png"),("item 0")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ko_big.png"), ("item 1 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/cable_ok.png"), ("item 2 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_PAGE.png"), ("item 3 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_MENU_ING.png"), ("item 4 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/tasto_MENU.png"), ("item 5 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_SU.png"), ("item 6 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_GIU.png"), ("item 7 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_B_SU.png"), ("item 8 ")));
         list->addItem(new QListWidgetItem(QIcon(":/pix/images/key_TAPPETO_B_ON_OFF.png"), ("item 9 ")));

         list->setViewMode(QListWidget::IconMode);
         list->setIconSize(QSize(28, 28));
         list->setGridSize(QSize(60, 60));
         list->setMaximumWidth(250);

}


