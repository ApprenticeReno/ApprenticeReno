#include "OpenGlWidget.h"
//#include "MainWindow.h"
#include <QDragEnterEvent>
#include <QMimeData>
#include <QPainter>
#include <QIcon>
#include <QtWidgets>
#include <QMessageBox>
#include <QDebug>
#include <QPushButton>

OpenGlWidget::OpenGlWidget(QWidget *parent) :
	QOpenGLWidget(parent)
{
	setAcceptDrops(true);

}

void OpenGlWidget::dragEnterEvent(QDragEnterEvent *event)
{
	QOpenGLWidget::dragEnterEvent(event);
	event->accept();
}

/*non funge

void OpenGlWidget::dragMoveEvent(QDragMoveEvent *event)
{
    QOpenGLWidget::dragMoveEvent(event);
    event->accept();
}*/

//-----------------------------------------------------------------------------------------------------------------------------------


void OpenGlWidget::dropEvent(QDropEvent *event) // evento drop sopra un elemto grafico di tipo grid layout
{
    const QMimeData *mimeData = event->mimeData(); //contenitore dati settato a formato qabstract item model data list

    if (mimeData->hasFormat("application/x-qabstractitemmodeldatalist")) { // i dati di tipo mime che puoi droppare
        QByteArray arraydati = mimeData->data("application/x-qabstractitemmodeldatalist"); // array di byte di tipo mimeData
        QDataStream stream(&arraydati, QIODevice::ReadOnly);

        while (!stream.atEnd()) {
            int row;
            int col;

            QMap<int,  QVariant> DataMap;
            // definizione DataMap compresa di un intero (che conterrà la riga riferita all'icona) ,
            //e una QVariant , che contine un valore singolo di un tipo specifico per volta (esempio stringa o icona )

            stream >> row >> col >> DataMap; // passa dati serializzati di riga e colonna , l'intero colonna serve per poter essere convertito in seguito

// setta stringa name di tipo DataMap(int,QVariant)dove intero passo valore 0,che si riferisce alla riga stessa, e per QVariant il valore stringa
            QString name = DataMap.value(0).toString();
//icon di tipo Qicon = Data map con intero 1 e QVariant che richihama il valore del tipo QIcon
            QIcon icon = DataMap.value(1).value<QIcon>();

            m_pixmap = icon.pixmap(icon.availableSizes().first());

            update();

            qDebug() <<"\n"<<"hai trascinato l'icona -----> "<<name<<"\n"; //

        }
    } else {
        event->ignore();
    }
}

//----------------------------------------------------------------------------------------------------------------------------------

void OpenGlWidget::paintGL()
{
	QPainter painter(this);
	painter.drawPixmap(0, 0, m_pixmap);
}





