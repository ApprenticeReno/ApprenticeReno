#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class MainWindow : public QMainWindow
{
	Q_OBJECT
public:
	explicit MainWindow(QWidget *parent = 0);

private slots:

    void on_button_clicked();
    void on_reset_clicked();

};

#endif // MAINWINDOW_H
