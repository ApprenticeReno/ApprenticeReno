#include "list.h"

List::List()
{

}
