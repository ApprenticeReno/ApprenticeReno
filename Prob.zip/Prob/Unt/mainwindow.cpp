#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QListWidgetItem>
#include <QHBoxLayout>
#include <QDrag>
#include <QIcon>
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
   ui->setupUi(this);
   this->setWindowTitle("Teleref_Smart_PTM_prototipoR1");

  /* ui->listWidget->addItem(new QListWidgetItem(QIcon(":/pix/images/key_BARRA_GIU.png"),tr("item0")));
   ui->listWidget->addItem(new QListWidgetItem(QIcon(":/pix/images/key_BARRA_SU.png"),tr("item1")));
   ui->listWidget->addItem(new QListWidgetItem(QIcon(":/pix/images/key_LATO_DESTRO_GIU.png"),tr("item2")));*/




  // ui->listWidget->iconSize();
/*
   ui->listWidget->setViewMode(QListWidget::IconMode);
   ui->listWidget->setIconSize(QSize(50, 50));
   ui->listWidget->setAcceptDrops(false);
   ui->listWidget->setDragEnabled(true);

   ui->OpenGLWidget->setAcceptDrops(true);
 */

}

//FUNZIONI MENU

void MainWindow::on_actionSalva_tutto_triggered()
{
 //save all to file
}

void MainWindow::on_actionChiudi_triggered()
{
   close();
}

void MainWindow::on_actionEsporta_CSV_triggered()
{
  //open e write file
}

void MainWindow::on_actionNuovo_triggered()
{
 //();
}


