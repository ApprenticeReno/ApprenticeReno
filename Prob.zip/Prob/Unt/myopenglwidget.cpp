#include "myopenglwidget.h"


MyOpenGLWidget::MyOpenGLWidget(QWidget *parent)
    : QOpenGLWidget {parent}
{

}

protected:
void MyOpenGLWidget::initializeGL(){

}
void MyOpenGLWidget::paintGL(){

}
void MyOpenGLWidget::resizeGL(int w,int h){

}
