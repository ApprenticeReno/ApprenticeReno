#ifndef LIST_H
#define LIST_H


class List
{
public:
    List();
};

#endif // LIST_H
