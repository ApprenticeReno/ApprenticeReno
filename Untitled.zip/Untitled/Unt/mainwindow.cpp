#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QListWidgetItem>
#include <QHBoxLayout>
#include <QDrag>
#include <QIcon>
#include <QPushButton>
#include <QMessageBox>
#include <QListWidgetItem>
#include <QList>
#include <QLayout>
#include <QMouseEvent>
#include <QAction>
#include <QCoreApplication>
#include <QMouseEvent>
#include <QPainter>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
   ui->setupUi(this);
   this->setWindowTitle("Teleref_Smart_PTM_prototipoR1");
// this->setStyleSheet("background-color: lightblue");    colore sfondo tot

 //  12 openglwidget.cpp x 1 tab, //60 openglwidget x 5 tab

   auto *gridLay=new QGridLayout(); //grid layout per i bottoni

 //  auto *vertLay=new QVBoxLayout();

   auto *btn0=new QPushButton("ic0");
   btn0->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn0->setIconSize(QSize(50,50));
  // btn0->dragMoveEvent();

   auto *btn1=new QPushButton("ic1");
   btn1->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn1->setIconSize(QSize(50,50));

   auto *btn2=new QPushButton("ic2");
   btn2->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn2->setIconSize(QSize(50,50));

   auto *btn3=new QPushButton("ic3");
   btn3->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn3->setIconSize(QSize(50,50));

   auto *btn4=new QPushButton("ic4");
   btn4->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn4->setIconSize(QSize(50,50));

   auto *btn5=new QPushButton("ic5");
   btn5->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn5->setIconSize(QSize(50,50));

   auto *btn6=new QPushButton("ic6");
   btn6->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn6->setIconSize(QSize(50,50));

   auto *btn7=new QPushButton("ic7");
   btn7->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn7->setIconSize(QSize(50,50));

   auto *btn8=new QPushButton("ic8");
   btn8->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn8->setIconSize(QSize(50,50));

   auto *btn9=new QPushButton("ic9");
   btn9->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn9->setIconSize(QSize(50,50));

   auto *btn10=new QPushButton("ic10");
   btn10->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn10->setIconSize(QSize(50,50));

   auto *btn11=new QPushButton("ic11");
   btn11->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn11->setIconSize(QSize(50,50));

   auto *btn12=new QPushButton("ic12");
   btn12->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn12->setIconSize(QSize(50,50));

   auto *btn13=new QPushButton("ic13");
   btn13->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn13->setIconSize(QSize(50,50));

   auto *btn14=new QPushButton("ic14");
   btn14->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn14->setIconSize(QSize(50,50));

   auto *btn15=new QPushButton("ic15");
   btn15->setIcon(QIcon(":/pix/images/key_BARRA_GIU.png"));
   btn15->setIconSize(QSize(50,50));

   auto *btn16=new QPushButton("ic16");
   btn16->setIcon(QIcon(":/pix/images/key_BARRA_SU.png"));
   btn16->setIconSize(QSize(50,50));

      gridLay->addWidget(btn0,0,0); //aggiunta bottone-icona al grid layout
      gridLay->addWidget(btn1,0,1);
      gridLay->addWidget(btn2,1,0);
      gridLay->addWidget(btn3,1,1);
      gridLay->addWidget(btn4,2,0);
      gridLay->addWidget(btn5,2,1);
      gridLay->addWidget(btn6,3,0);
      gridLay->addWidget(btn7,3,1);
      gridLay->addWidget(btn8,4,0);
      gridLay->addWidget(btn9,4,1);
      gridLay->addWidget(btn10,5,0);
      gridLay->addWidget(btn11,5,1);
      gridLay->addWidget(btn12,6,0);
      gridLay->addWidget(btn13,6,1);
      gridLay->addWidget(btn14,7,0);
      gridLay->addWidget(btn15,7,1);

   ui->scrollContents->setLayout(gridLay);

   ui->frame->setStyleSheet("border :0.5px solid black"); //brodo frame configurazione tasto
 //  ui->scrollArea->setLayout(gridLay);

  //connessione bottone funzione
  connect(btn0,SIGNAL(clicked()),this,SLOT(on_btn0_clicked()));
  connect(btn1,SIGNAL(clicked()),this,SLOT(on_btn1_clicked()));

}

//FUNZIONI DRAG BOTTONI

void MainWindow::dragMoveEvent(QDragMoveEvent *event)
{
    event->accept();
}


//FUNZIONI SETTAGGIO CONFIGURAZIONE A BOTTONE ICONA ---------------------------------------------------------------------------
void MainWindow::on_btn0_clicked(){

ui->label_12->setText(QString(" 0 -> Barra_giu"));

}

void MainWindow::on_btn1_clicked(){

    ui->label_12->setText(QString(" 1 -> Barra_Su")); //set text icone
}

//FUNZIONI MENU ------------------------------------------------------------------------------------------------------------------
void MainWindow::on_actionSalva_tutto_triggered()
{
 //save all to file
}

void MainWindow::on_actionChiudi_triggered()
{
   close();
}

void MainWindow::on_actionEsporta_CSV_triggered()
{
  //open e write file
}

void MainWindow::on_actionNuovo_triggered()
{
 //();
}


