#ifndef MYOPENGLWIDGET_H
#define MYOPENGLWIDGET_H

#include <QOpenGLWidget>
#include <QOpenGLFunctions>

class MyOpenGLWidget : public QOpenGLWidget, public QOpenGLFunctions
{
public:
    MyOpenGLWidget(QWidget *parent=nullptr);

protected:
    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int w,int h) override;

};

#endif // MYOPENGLWIDGET_H
