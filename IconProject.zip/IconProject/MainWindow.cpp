#include "MainWindow.h"
#include "List.h"
#include "OpenGlWidget.h"
#include <QGridLayout>
#include <QLabel>

MainWindow::MainWindow(QWidget *parent) :
	QMainWindow(parent)
{
	auto *widget = new QWidget(this);
	auto *layoutMain = new QHBoxLayout(widget);
	auto *list = new List(this);

    auto *viewLeft1 = new OpenGlWidget(this);
    auto *viewRight1 = new OpenGlWidget(this);
    auto *viewLeft2 = new OpenGlWidget(this);
    auto *viewRight2 = new OpenGlWidget(this);
    auto *viewLeft3 = new OpenGlWidget(this);
    auto *viewRight3 = new OpenGlWidget(this);
    auto *viewLeft4 = new OpenGlWidget(this);
    auto *viewRight4 = new OpenGlWidget(this);
    auto *viewLeft5 = new OpenGlWidget(this);
    auto *viewRight5 = new OpenGlWidget(this);
    auto *viewLeft6 = new OpenGlWidget(this);
    auto *viewRight6 = new OpenGlWidget(this);
    auto *viewLeft7 = new OpenGlWidget(this);
    auto *viewRight7 = new OpenGlWidget(this);
    auto *viewLeft8 = new OpenGlWidget(this);
    auto *viewRight8 = new OpenGlWidget(this);
    auto *viewLeft9 = new OpenGlWidget(this);
    auto *viewRight9 = new OpenGlWidget(this);
    auto *viewLeft10 = new OpenGlWidget(this);
    auto *viewRight10 = new OpenGlWidget(this);

	auto *layoutGrid = new QGridLayout();

    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon1.png"),tr("Item 1")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon2.png"), tr("Item 2")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon3.png"), tr("Item 3")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon4.png"), tr("Item 4")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon5.png"), tr("Item 5")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon6.png"), tr("Item 6")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon7.png"), tr("Item 7")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon8.png"), tr("Item 8")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon9.png"), tr("Item 9")));
    list->addItem(new QListWidgetItem(QIcon(":/pix/images/icon10.png"), tr("Item 10")));


	list->setViewMode(QListWidget::IconMode);
    list->setIconSize(QSize(28, 28));
    list->setGridSize(QSize(60, 60));
    list->setMaximumWidth(300); 

     layoutGrid->addWidget(viewLeft1,1,0);
     layoutGrid->addWidget(viewRight1,1,1);
     layoutGrid->addWidget(viewLeft2,2,0);
     layoutGrid->addWidget(viewRight2,2,1);
     layoutGrid->addWidget(viewLeft3,3,0);
     layoutGrid->addWidget(viewRight3,3,1);
     layoutGrid->addWidget(viewLeft4,4,0);
     layoutGrid->addWidget(viewRight4,4,1);
     layoutGrid->addWidget(viewLeft5,5,0);
     layoutGrid->addWidget(viewRight5,5,1);
     layoutGrid->addWidget(viewLeft6,6,0);
     layoutGrid->addWidget(viewRight6,6,1);
     layoutGrid->addWidget(viewLeft7,7,0);
     layoutGrid->addWidget(viewRight7,7,1);
     layoutGrid->addWidget(viewLeft8,8,0);
     layoutGrid->addWidget(viewRight8,8,1);
     layoutGrid->addWidget(viewLeft9,9,0);
     layoutGrid->addWidget(viewRight9,9,1);
     layoutGrid->addWidget(viewLeft10,10,0);
     layoutGrid->addWidget(viewRight10,10,1);


    layoutMain->addWidget(list); // add list to layout
	layoutMain->addLayout(layoutGrid); //add grid layout to main layout

	setCentralWidget(widget);
    resize(600, 900);
}
